# Ultralytics YOLO 🚀, AGPL-3.0 license

import os
import torch
import torch.nn as nn
import torch.nn.functional as F
import dill as pickle

from ultralytics.utils.loss import FocalLoss, VarifocalLoss, SlideLoss, EMASlideLoss, SlideVarifocalLoss, EMASlideVarifocalLoss, MALoss
from ultralytics.utils.metrics import bbox_iou, bbox_inner_iou, bbox_focaler_iou, bbox_mpdiou, bbox_inner_mpdiou, bbox_focaler_mpdiou, wasserstein_loss, gcd_loss, WiseIouLoss

from .ops import HungarianMatcher


class DETRLoss(nn.Module):
    """
    DETR (DEtection TRansformer) Loss class. This class calculates and returns the different loss components for the
    DETR object detection model. It computes classification loss, bounding box loss, GIoU loss, and optionally auxiliary
    losses.

    Attributes:
        nc (int): The number of classes.
        loss_gain (dict): Coefficients for different loss components.
        aux_loss (bool): Whether to compute auxiliary losses.
        use_fl (bool): Use FocalLoss or not.
        use_vfl (bool): Use VarifocalLoss or not.
        use_uni_match (bool): Whether to use a fixed layer to assign labels for the auxiliary branch.
        uni_match_ind (int): The fixed indices of a layer to use if `use_uni_match` is True.
        matcher (HungarianMatcher): Object to compute matching cost and indices.
        fl (FocalLoss or None): Focal Loss object if `use_fl` is True, otherwise None.
        vfl (VarifocalLoss or None): Varifocal Loss object if `use_vfl` is True, otherwise None.
        device (torch.device): Device on which tensors are stored.
    """

    def __init__(self,
                 nc=80,
                 loss_gain=None,
                 aux_loss=True,
                 use_fl=True,
                 use_vfl=False,
                 use_sl=False, # SlideLoss
                 use_emasl=False, # EMASlideLoss
                 use_svfl=False, # SlideVarifocalLoss
                 use_emasvfl=False, # EMASlideVarifocalLoss
                 use_mal=False, # CVPR2025-DEIM MAL
                 use_uni_match=False,
                 uni_match_ind=0):
        """
        DETR loss function.

        Args:
            nc (int): The number of classes.
            loss_gain (dict): The coefficient of loss.
            aux_loss (bool): If 'aux_loss = True', loss at each decoder layer are to be used.
            use_vfl (bool): Use VarifocalLoss or not.
            use_uni_match (bool): Whether to use a fixed layer to assign labels for auxiliary branch.
            uni_match_ind (int): The fixed indices of a layer.
        """
        super().__init__()

        if loss_gain is None:
            loss_gain = {'class': 1, 'bbox': 5, 'giou': 2, 'no_object': 0.1, 'mask': 1, 'dice': 1}
        self.nc = nc
        self.matcher = HungarianMatcher(cost_gain={'class': 2, 'bbox': 5, 'giou': 2})
        self.loss_gain = loss_gain
        self.aux_loss = aux_loss
        self.fl = FocalLoss() if use_fl else None
        self.vfl = VarifocalLoss() if use_vfl else None
        self.sl = SlideLoss(nn.BCEWithLogitsLoss(reduction='none')) if use_sl else None
        self.emasl = EMASlideLoss(nn.BCEWithLogitsLoss(reduction='none')) if use_emasl else None
        self.svfl = SlideVarifocalLoss() if use_svfl else None
        self.emasvfl = EMASlideVarifocalLoss() if use_emasvfl else None
        self.mal = MALoss() if use_mal else None

        self.use_uni_match = use_uni_match
        self.uni_match_ind = uni_match_ind
        self.device = None
        
        # for nwd loss
        self.nwd_loss = False
        # for gcd loss
        self.gcd_loss = False
        self.iou_ratio = 0.5 # total_iou_loss = self.iou_ratio * iou_loss + (1 - self.iou_ratio) * (nwd_loss or gcd_loss)
        
        # for wise-iou loss
        self.use_wiseiou = False
        if self.use_wiseiou:
            self.wiou_loss = WiseIouLoss(ltype='WIoU', monotonous=False, inner_iou=False, focaler_iou=False)

        # C innovation: IS-NWD-Lite (Input-Space aware NWD-Lite Loss).
        # This is not a direct replacement of the original RT-DETR regression loss.
        # It keeps the original L1 + GIoU loss unchanged and adds a small,
        # scale-gated NWD auxiliary term for small-object localization.
        self.use_nwdlite = os.getenv('RTDETR_USE_NWDLITE', '0').lower() in ('1', 'true', 'yes')
        self.nwdlite_lambda = float(os.getenv('RTDETR_NWDLITE_LAMBDA', '0.05'))
        self.nwdlite_tau = float(os.getenv('RTDETR_NWDLITE_TAU', '0.08'))
        self.nwdlite_temp = float(os.getenv('RTDETR_NWDLITE_TEMP', '0.03'))
        # The official NWD is usually formulated in image/pixel coordinates.
        # RT-DETR loss here uses normalized xywh boxes, so we use a normalized
        # distance constant. This is the input-space adaptation in IS-NWD-Lite.
        self.nwdlite_constant = float(os.getenv('RTDETR_NWDLITE_CONSTANT', '0.50'))
        self.nwdlite_eps = 1e-7

        # C innovation: IS-WIoU-Lite (Input-Space aware Wise-IoU Lite Loss).
        # Based on the open-source Wise-IoU v3 dynamic focusing mechanism, but
        # adapted as a conservative RT-DETR input-space regression term.
        # It replaces the matched GIoU term with a mixture of original GIoU and
        # scale-gated WIoU, while keeping the original L1 loss and Hungarian matcher unchanged.
        self.use_iswiou = os.getenv('RTDETR_USE_ISWIOU', '0').lower() in ('1', 'true', 'yes')
        self.iswiou_mix = float(os.getenv('RTDETR_ISWIOU_MIX', '0.70'))
        self.iswiou_tau = float(os.getenv('RTDETR_ISWIOU_TAU', '0.10'))
        self.iswiou_temp = float(os.getenv('RTDETR_ISWIOU_TEMP', '0.04'))
        self.iswiou_ratio = float(os.getenv('RTDETR_ISWIOU_RATIO', '1.0'))
        self.iswiou_eps = 1e-7
        self.iswiou_loss = WiseIouLoss(ltype='WIoU', monotonous=False, inner_iou=False, focaler_iou=False) if self.use_iswiou else None

    def _nwdlite_gate(self, gt_bboxes):
        """Return a normalized smooth gate that focuses the NWD term on small objects.

        gt_bboxes are normalized xywh boxes. The gate is high for small objects and
        low for large objects, but its mean is normalized to keep the auxiliary loss
        scale stable across images and batches.
        """
        if (not self.use_nwdlite) or len(gt_bboxes) == 0:
            return None
        wh = gt_bboxes[:, 2:4].detach().clamp(min=self.nwdlite_eps, max=1.0)
        obj_scale = torch.sqrt((wh[:, 0] * wh[:, 1]).clamp(min=self.nwdlite_eps, max=1.0))
        gate = torch.sigmoid((self.nwdlite_tau - obj_scale) / max(self.nwdlite_temp, self.nwdlite_eps))
        gate = gate / gate.mean().clamp(min=self.nwdlite_eps)
        return gate


    def _iswiou_gate(self, gt_bboxes):
        """Normalized input-space small-object gate for IS-WIoU-Lite.

        The gate is high for small GT boxes and close to 1 on average, so the
        dynamic WIoU term focuses more on UAV small objects without changing the
        overall loss scale too aggressively.
        """
        if (not self.use_iswiou) or len(gt_bboxes) == 0:
            return None
        wh = gt_bboxes[:, 2:4].detach().clamp(min=self.iswiou_eps, max=1.0)
        obj_scale = torch.sqrt((wh[:, 0] * wh[:, 1]).clamp(min=self.iswiou_eps, max=1.0))
        gate = 1.0 + torch.sigmoid((self.iswiou_tau - obj_scale) / max(self.iswiou_temp, self.iswiou_eps))
        gate = gate / gate.mean().clamp(min=self.iswiou_eps)
        return gate

    def _get_loss_class(self, pred_scores, targets, gt_scores, num_gts, postfix=''):
        """Computes the classification loss based on predictions, target values, and ground truth scores."""
        # Logits: [b, query, num_classes], gt_class: list[[n, 1]]
        name_class = f'loss_class{postfix}'
        bs, nq = pred_scores.shape[:2]
        # one_hot = F.one_hot(targets, self.nc + 1)[..., :-1]  # (bs, num_queries, num_classes)
        one_hot = torch.zeros((bs, nq, self.nc + 1), dtype=torch.int64, device=targets.device)
        one_hot.scatter_(2, targets.unsqueeze(-1), 1)
        one_hot = one_hot[..., :-1]
        gt_scores = gt_scores.view(bs, nq, 1) * one_hot

        if self.sl or self.emasl:
            if num_gts > 0:
                auto_iou = (gt_scores[gt_scores > 0]).mean()
            else:
                auto_iou = -1
            if self.sl:
                loss_cls = self.sl(pred_scores, gt_scores, auto_iou).mean(1).sum()
            else:
                loss_cls = self.emasl(pred_scores, gt_scores, auto_iou).mean(1).sum()
        elif self.svfl or self.emasvfl:
            if num_gts > 0:
                auto_iou = (gt_scores[gt_scores > 0]).mean()
            else:
                auto_iou = -1
            if num_gts:
                if self.svfl:
                    loss_cls = self.svfl(pred_scores, gt_scores, one_hot, auto_iou)
                else:
                    loss_cls = self.emasvfl(pred_scores, gt_scores, one_hot, auto_iou)
            else:
                loss_cls = self.fl(pred_scores, one_hot.float())
            loss_cls /= max(num_gts, 1) / nq
        elif self.fl:
            if num_gts:
                if self.vfl:
                    loss_cls = self.vfl(pred_scores, gt_scores, one_hot)
                elif self.mal:
                    loss_cls = self.mal(pred_scores, gt_scores, one_hot)
            else:
                loss_cls = self.fl(pred_scores, one_hot.float())
            loss_cls /= max(num_gts, 1) / nq
        else:
            loss_cls = nn.BCEWithLogitsLoss(reduction='none')(pred_scores, gt_scores).mean(1).sum()  # YOLO CLS loss

        return {name_class: loss_cls.squeeze() * self.loss_gain['class']}

    def _get_loss_bbox(self, pred_bboxes, gt_bboxes, postfix=''):
        """Calculates and returns the bounding box loss and GIoU loss for the predicted and ground truth bounding
        boxes.
        """
        # Boxes: [b, query, 4], gt_bbox: list[[n, 4]]
        name_bbox = f'loss_bbox{postfix}'
        name_giou = f'loss_giou{postfix}'

        loss = {}
        if len(gt_bboxes) == 0:
            loss[name_bbox] = torch.tensor(0., device=self.device)
            loss[name_giou] = torch.tensor(0., device=self.device)
            return loss

        # Keep the original RT-DETR L1 box regression loss unchanged.
        loss[name_bbox] = self.loss_gain['bbox'] * F.l1_loss(pred_bboxes, gt_bboxes, reduction='sum') / len(gt_bboxes)
        # Original RT-DETR GIoU vector in normalized input-space coordinates.
        base_giou_vec = 1.0 - bbox_iou(pred_bboxes, gt_bboxes, xywh=True, GIoU=True)
        loss[name_giou] = base_giou_vec
        # loss[name_giou] = 1.0 - bbox_inner_iou(pred_bboxes, gt_bboxes, xywh=True, GIoU=True, ratio=0.7) # Inner IoU
        # loss[name_giou] = 1.0 - bbox_focaler_iou(pred_bboxes, gt_bboxes, xywh=True, GIoU=True, d=0.0, u=0.95) # Focaler IoU
        # loss[name_giou] = 1.0 - bbox_mpdiou(pred_bboxes, gt_bboxes, xywh=True, mpdiou_hw=2) # MPDIoU
        # loss[name_giou] = 1.0 - bbox_inner_mpdiou(pred_bboxes, gt_bboxes, xywh=True, mpdiou_hw=2, ratio=0.7) # Inner-MPDIoU
        # loss[name_giou] = 1.0 - bbox_focaler_mpdiou(pred_bboxes, gt_bboxes, xywh=True, mpdiou_hw=2, d=0.0, u=0.95) # Focaler-MPDIoU
        
        if self.use_iswiou and self.iswiou_loss is not None:
            # IS-WIoU-Lite: use the open-source Wise-IoU v3 dynamic focusing loss,
            # but adapt it to RT-DETR by mixing with the original GIoU term and
            # applying a normalized small-object gate in input-space coordinates.
            giou_term = base_giou_vec.sum() / len(gt_bboxes)
            wiou_vec = self.iswiou_loss(pred_bboxes, gt_bboxes, ret_iou=False, ratio=self.iswiou_ratio).view(-1)
            gate = self._iswiou_gate(gt_bboxes)
            if gate is not None:
                wiou_term = (wiou_vec * gate).sum() / len(gt_bboxes)
            else:
                wiou_term = wiou_vec.sum() / len(gt_bboxes)
            mix = max(0.0, min(1.0, self.iswiou_mix))
            loss[name_giou] = (1.0 - mix) * giou_term + mix * wiou_term
        elif self.nwd_loss:
            nwd = wasserstein_loss(pred_bboxes, gt_bboxes)
            loss[name_giou] = self.iou_ratio * (loss[name_giou].sum() / len(gt_bboxes)) + (1.0 - self.iou_ratio) * ((1.0 - nwd).sum() / len(gt_bboxes))
        elif self.gcd_loss:
            gcd = gcd_loss(pred_bboxes, gt_bboxes)
            # 现在不需要乘以0.0002了
            loss[name_giou] = self.iou_ratio * (loss[name_giou].sum() / len(gt_bboxes)) + (1.0 - self.iou_ratio) * ((1.0 - gcd).sum() / len(gt_bboxes))
        else:
            loss[name_giou] = loss[name_giou].sum() / len(gt_bboxes)

            # IS-NWD-Lite: add a small scale-gated NWD auxiliary term after matching.
            # It does not replace GIoU and does not change Hungarian matching.
            if self.use_nwdlite and self.nwdlite_lambda > 0:
                nwd_sim = wasserstein_loss(
                    pred_bboxes, gt_bboxes, xywh=True, constant=self.nwdlite_constant
                ).view(-1)
                nwd_aux = 1.0 - nwd_sim
                nwd_gate = self._nwdlite_gate(gt_bboxes)
                if nwd_gate is not None:
                    nwd_aux = (nwd_aux * nwd_gate).sum() / len(gt_bboxes)
                else:
                    nwd_aux = nwd_aux.sum() / len(gt_bboxes)
                loss[name_giou] = loss[name_giou] + self.nwdlite_lambda * nwd_aux
        loss[name_giou] = self.loss_gain['giou'] * loss[name_giou]
        return {k: v.squeeze() for k, v in loss.items()}

    # This function is for future RT-DETR Segment models
    # def _get_loss_mask(self, masks, gt_mask, match_indices, postfix=''):
    #     # masks: [b, query, h, w], gt_mask: list[[n, H, W]]
    #     name_mask = f'loss_mask{postfix}'
    #     name_dice = f'loss_dice{postfix}'
    #
    #     loss = {}
    #     if sum(len(a) for a in gt_mask) == 0:
    #         loss[name_mask] = torch.tensor(0., device=self.device)
    #         loss[name_dice] = torch.tensor(0., device=self.device)
    #         return loss
    #
    #     num_gts = len(gt_mask)
    #     src_masks, target_masks = self._get_assigned_bboxes(masks, gt_mask, match_indices)
    #     src_masks = F.interpolate(src_masks.unsqueeze(0), size=target_masks.shape[-2:], mode='bilinear')[0]
    #     # TODO: torch does not have `sigmoid_focal_loss`, but it's not urgent since we don't use mask branch for now.
    #     loss[name_mask] = self.loss_gain['mask'] * F.sigmoid_focal_loss(src_masks, target_masks,
    #                                                                     torch.tensor([num_gts], dtype=torch.float32))
    #     loss[name_dice] = self.loss_gain['dice'] * self._dice_loss(src_masks, target_masks, num_gts)
    #     return loss

    # This function is for future RT-DETR Segment models
    # @staticmethod
    # def _dice_loss(inputs, targets, num_gts):
    #     inputs = F.sigmoid(inputs).flatten(1)
    #     targets = targets.flatten(1)
    #     numerator = 2 * (inputs * targets).sum(1)
    #     denominator = inputs.sum(-1) + targets.sum(-1)
    #     loss = 1 - (numerator + 1) / (denominator + 1)
    #     return loss.sum() / num_gts

    def _get_loss_aux(self,
                      pred_bboxes,
                      pred_scores,
                      gt_bboxes,
                      gt_cls,
                      gt_groups,
                      match_indices=None,
                      postfix='',
                      masks=None,
                      gt_mask=None):
        """Get auxiliary losses."""
        # NOTE: loss class, bbox, giou, mask, dice
        loss = torch.zeros(5 if masks is not None else 3, device=pred_bboxes.device)
        if match_indices is None and self.use_uni_match:
            match_indices = self.matcher(pred_bboxes[self.uni_match_ind],
                                         pred_scores[self.uni_match_ind],
                                         gt_bboxes,
                                         gt_cls,
                                         gt_groups,
                                         masks=masks[self.uni_match_ind] if masks is not None else None,
                                         gt_mask=gt_mask)
        for i, (aux_bboxes, aux_scores) in enumerate(zip(pred_bboxes, pred_scores)):
            aux_masks = masks[i] if masks is not None else None
            loss_ = self._get_loss(aux_bboxes,
                                   aux_scores,
                                   gt_bboxes,
                                   gt_cls,
                                   gt_groups,
                                   masks=aux_masks,
                                   gt_mask=gt_mask,
                                   postfix=postfix,
                                   match_indices=match_indices)
            loss[0] += loss_[f'loss_class{postfix}']
            loss[1] += loss_[f'loss_bbox{postfix}']
            loss[2] += loss_[f'loss_giou{postfix}']
            # if masks is not None and gt_mask is not None:
            #     loss_ = self._get_loss_mask(aux_masks, gt_mask, match_indices, postfix)
            #     loss[3] += loss_[f'loss_mask{postfix}']
            #     loss[4] += loss_[f'loss_dice{postfix}']

        loss = {
            f'loss_class_aux{postfix}': loss[0],
            f'loss_bbox_aux{postfix}': loss[1],
            f'loss_giou_aux{postfix}': loss[2]}
        # if masks is not None and gt_mask is not None:
        #     loss[f'loss_mask_aux{postfix}'] = loss[3]
        #     loss[f'loss_dice_aux{postfix}'] = loss[4]
        return loss

    @staticmethod
    def _get_index(match_indices):
        """Returns batch indices, source indices, and destination indices from provided match indices."""
        batch_idx = torch.cat([torch.full_like(src, i) for i, (src, _) in enumerate(match_indices)])
        src_idx = torch.cat([src for (src, _) in match_indices])
        dst_idx = torch.cat([dst for (_, dst) in match_indices])
        return (batch_idx, src_idx), dst_idx

    def _get_assigned_bboxes(self, pred_bboxes, gt_bboxes, match_indices):
        """Assigns predicted bounding boxes to ground truth bounding boxes based on the match indices."""
        pred_assigned = torch.cat([
            t[I] if len(I) > 0 else torch.zeros(0, t.shape[-1], device=self.device)
            for t, (I, _) in zip(pred_bboxes, match_indices)])
        gt_assigned = torch.cat([
            t[J] if len(J) > 0 else torch.zeros(0, t.shape[-1], device=self.device)
            for t, (_, J) in zip(gt_bboxes, match_indices)])
        return pred_assigned, gt_assigned

    def _get_loss(self,
                  pred_bboxes,
                  pred_scores,
                  gt_bboxes,
                  gt_cls,
                  gt_groups,
                  masks=None,
                  gt_mask=None,
                  postfix='',
                  match_indices=None):
        """Get losses."""
        if match_indices is None:
            match_indices = self.matcher(pred_bboxes,
                                         pred_scores,
                                         gt_bboxes,
                                         gt_cls,
                                         gt_groups,
                                         masks=masks,
                                         gt_mask=gt_mask)

        idx, gt_idx = self._get_index(match_indices)
        pred_bboxes, gt_bboxes = pred_bboxes[idx], gt_bboxes[gt_idx]

        bs, nq = pred_scores.shape[:2]
        targets = torch.full((bs, nq), self.nc, device=pred_scores.device, dtype=gt_cls.dtype)
        targets[idx] = gt_cls[gt_idx]

        gt_scores = torch.zeros([bs, nq], device=pred_scores.device)
        if len(gt_bboxes):
            gt_scores[idx] = bbox_iou(pred_bboxes.detach(), gt_bboxes, xywh=True).squeeze(-1)

        loss = {}
        loss.update(self._get_loss_class(pred_scores, targets, gt_scores, len(gt_bboxes), postfix))
        loss.update(self._get_loss_bbox(pred_bboxes, gt_bboxes, postfix))
        # if masks is not None and gt_mask is not None:
        #     loss.update(self._get_loss_mask(masks, gt_mask, match_indices, postfix))
        return loss

    def forward(self, pred_bboxes, pred_scores, batch, postfix='', **kwargs):
        """
        Args:
            pred_bboxes (torch.Tensor): [l, b, query, 4]
            pred_scores (torch.Tensor): [l, b, query, num_classes]
            batch (dict): A dict includes:
                gt_cls (torch.Tensor) with shape [num_gts, ],
                gt_bboxes (torch.Tensor): [num_gts, 4],
                gt_groups (List(int)): a list of batch size length includes the number of gts of each image.
            postfix (str): postfix of loss name.
        """
        self.device = pred_bboxes.device
        match_indices = kwargs.get('match_indices', None)
        gt_cls, gt_bboxes, gt_groups = batch['cls'], batch['bboxes'], batch['gt_groups']

        total_loss = self._get_loss(pred_bboxes[-1],
                                    pred_scores[-1],
                                    gt_bboxes,
                                    gt_cls,
                                    gt_groups,
                                    postfix=postfix,
                                    match_indices=match_indices)

        if self.aux_loss:
            total_loss.update(
                self._get_loss_aux(pred_bboxes[:-1], pred_scores[:-1], gt_bboxes, gt_cls, gt_groups, match_indices,
                                   postfix))

        return total_loss


class RTDETRDetectionLoss(DETRLoss):
    """
    Real-Time DeepTracker (RT-DETR) Detection Loss class that extends the DETRLoss.

    This class computes the detection loss for the RT-DETR model, which includes the standard detection loss as well as
    an additional denoising training loss when provided with denoising metadata.
    """

    def forward(self, preds, batch, dn_bboxes=None, dn_scores=None, dn_meta=None):
        """
        Forward pass to compute the detection loss.

        Args:
            preds (tuple): Predicted bounding boxes and scores.
            batch (dict): Batch data containing ground truth information.
            dn_bboxes (torch.Tensor, optional): Denoising bounding boxes. Default is None.
            dn_scores (torch.Tensor, optional): Denoising scores. Default is None.
            dn_meta (dict, optional): Metadata for denoising. Default is None.

        Returns:
            (dict): Dictionary containing the total loss and, if applicable, the denoising loss.
        """
        pred_bboxes, pred_scores = preds
        total_loss = super().forward(pred_bboxes, pred_scores, batch)

        # Check for denoising metadata to compute denoising training loss
        if dn_meta is not None:
            dn_pos_idx, dn_num_group = dn_meta['dn_pos_idx'], dn_meta['dn_num_group']
            assert len(batch['gt_groups']) == len(dn_pos_idx)

            # Get the match indices for denoising
            match_indices = self.get_dn_match_indices(dn_pos_idx, dn_num_group, batch['gt_groups'])

            # Compute the denoising training loss
            dn_loss = super().forward(dn_bboxes, dn_scores, batch, postfix='_dn', match_indices=match_indices)
            total_loss.update(dn_loss)
        else:
            # If no denoising metadata is provided, set denoising loss to zero
            total_loss.update({f'{k}_dn': torch.tensor(0., device=self.device) for k in total_loss.keys()})

        return total_loss

    @staticmethod
    def get_dn_match_indices(dn_pos_idx, dn_num_group, gt_groups):
        """
        Get the match indices for denoising.

        Args:
            dn_pos_idx (List[torch.Tensor]): List of tensors containing positive indices for denoising.
            dn_num_group (int): Number of denoising groups.
            gt_groups (List[int]): List of integers representing the number of ground truths for each image.

        Returns:
            (List[tuple]): List of tuples containing matched indices for denoising.
        """
        dn_match_indices = []
        idx_groups = torch.as_tensor([0, *gt_groups[:-1]]).cumsum_(0)
        for i, num_gt in enumerate(gt_groups):
            if num_gt > 0:
                gt_idx = torch.arange(end=num_gt, dtype=torch.long) + idx_groups[i]
                gt_idx = gt_idx.repeat(dn_num_group)
                assert len(dn_pos_idx[i]) == len(gt_idx), 'Expected the same length, '
                f'but got {len(dn_pos_idx[i])} and {len(gt_idx)} respectively.'
                dn_match_indices.append((dn_pos_idx[i], gt_idx))
            else:
                dn_match_indices.append((torch.zeros([0], dtype=torch.long), torch.zeros([0], dtype=torch.long)))
        return dn_match_indices
