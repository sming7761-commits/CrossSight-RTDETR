```
sh make.sh
```
